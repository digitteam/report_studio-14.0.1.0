from . import report_studio
from . import qweb
from . import ir_view_qweb_action
